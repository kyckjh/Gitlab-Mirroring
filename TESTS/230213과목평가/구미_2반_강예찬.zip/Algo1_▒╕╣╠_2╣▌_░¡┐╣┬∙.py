T = int(input())
for t in range(1, T+1):
    N, M = map(int, input().split())
    board = list([0] * N for _ in range(N)) # 도화지 크기만큼 배열 생성
    for _ in range(M): # 입력 수 만큼 반복
        # (x, y) : 도장의 왼쪽 모서리 좌표(열, 행)
        # (w, h) : 도장의 너비와 높이
        y, x, w, h = map(int, input().split())
        for i in range(y, y+h): # 도장 위쪽 좌표부터 높이만큼 이동
            for j in range(x, x+w): # 도장 왼쪽 좌표부터 너비만큼 이동
                # 도장이 찍히는 좌표에 1 저장 (중복해서 찍혀도 값은 1 고정)
                board[i][j] = 1
    result = 0
    # 배열에 저장된 값 모두 더하기
    for i in range(N):
        for j in range(N):
            result += board[i][j]
    print(f'#{t} {result}')