T = int(input())
for t in range(1, T+1):
    N = int(input())
    r, c = map(int, input().split()) # 망치 좌표
    result = 0
    for _ in range(N):
        A, B, K = map(int, input().split()) # 두더지의 좌표와 남은 시간
        while K > 0: # 남은 시간이 0보다 클 때만 이동
            # 가로방향 먼저 확인
            # 망치가 두더지보다 오른쪽에 있으면 왼쪽으로 한 칸 이동
            if B < c:
                c -= 1
            # 망치가 두더지보다 왼쪽에 있으면 오른쪽으로 한 칸 이동
            elif B > c:
                c += 1
            # 가로방향이 같으면 세로방향 확인
            # 망치가 두더지보다 아래쪽에 있으면 위로 한 칸 이동
            elif A < r:
                r -= 1
            # 망치가 두더지보다 위쪽에 있으면 아래로 한 칸 이동
            elif A > r:
                r += 1
            # 망치와 두더지의 좌표가 같아지면 반복문 탈출
            if A == r and B == c:
                break
            K -= 1 # 한 칸 이동 후 남은시간 1 감소
        if A == r and B == c: # 망치가 두더지를 때릴 수 있으면 점수 획득
            result += 1
    print(f'#{t} {result}')